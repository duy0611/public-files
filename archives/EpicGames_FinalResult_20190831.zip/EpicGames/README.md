# Epic Games Programming Excercise

## Question 1

### Estimated time: 1 hour
### Solution

With assumption that we can break both Xboxes during our search, we can use the first Xbox to limit the search range and the second Xbox to determine the highest floor we can drop the Xbox.

In order to limit the search range, we will start from the most bottom of the building. Let denote X as the amount of floors that we jump from the base floor (zero floor). If the 1st Xbox breaks at X'th floor, we will use the 2nd Xbox to determine the highest possible floor. That can be achieved by starting from zero floor, and increase one by one until it is finnaly broken. If the 1st Xbox does not break at X'th floor, we will continue to 2X'th floor. We get the same situation again, either the Xbox is broken or not at this 2X'th floor. If broken, we start searching from X+1'th floor again. Otherwise, we continue to 3X'th floor.

We continue like this until the 1st Xbox is broken OR we reach the final floor of the building.

Our problem is to find the value of X so that we can use the fewest possible number of drops, to find the highest floor where we can drop the box and have it survive, IN THE WORST CASE.

We have the following possible cases:
* At X'th floor: the worst number is `1+(X-1)=X`
* At 2X'th floor: the worst number is `2+(X-1)=X+1`

  ...........

* At nX'th floor: thw worst number is `X+n-1`

Where `1 <= X <= 120 and 1 <= n <= 120 and nX <= 120 <= (n+1)X`

We need to find the **minimum of (X+n-1)** following the above condition.
```
From this condition (nX <= 120 <= (n+1)X), we can deduce the following: (120/X + X -1 <= n+X <= 120/X + X)

Let denote F(X) = 120/X + X

Taking the derivative of F(X), we have: F'(X) = 1 - 120/X**2

We can find min(F(X)) when F'(X) = 0, or when X = sqrt(120)

Since X is positive integer, X can be 10 or 11

If X=10, n will be 12. The worst possible drops is 12+10-1=21
If X=11, n will be 10. The worst possible drops is 10+11-1=20
```

As a result, **with X=11**, we can use the fewest posisble number of drops to find the highest floor where it can survice.

## Question 2

### Estimated time: 1.5 hours
### Solution

Assuming that this is a single-player mobile game, we will have the following API design:
```
GET /v1/api/games/:id
```
* Prequisities: User has to be authorized to call this method
* Description: To return in which region and mode the game is being played
* Input: 

   | Parameter    | Type  | Description             |
   | ------------ |:-----:| ----------------------- |
   | id (required)| Long  | Id of game being played |

* Output: Return the game being played

```json
{
    "id": 1,
    "createdTime": "2019-08-30T12:00:00.000Z",
    "status": "InProgress",
    "userId": 1,
    "region": {
        "id": 1,
        "countryCode": "fi",
        "countryName": "Finland"
    },
    "gameMode": {
        "id": 1,
        "name": "Survival Mode",
        "description": "some description here"
    }
}
```

```
GET /v1/api/gameModes/mostPopular?countryCode=fi
```
* Prequisities: User has to be authorized to call this method
* Description: To query the current most popular game modes for the region in which the player is located
* Input: 

   | Parameter             | Type   | Description             |
   | --------------------- |:------:| ----------------------- |
   | countryCode (optional)| String | 2 letter country codes (ISO 3166) to represent a region. If not specified, the country code will be extracted from the current region of logged in user |

* Output: Return the list of game modes for specified region

```json
[
    {
        "id": 1,
        "name": "Survival Mode",
        "description": "some description here",
        "gameModeStats": {
            "id": 1,
            "region": "fi",
            "playedTimes": 500,
            "rating": 4.5,
            "recommendTimes": 25
        }
    },
    {
        "id": 2,
        "name": "Unlimited Mode",
        "description": "some description here",
        "gameModeStats": {
            "id": 2,
            "region": "fi",
            "playedTimes": 300,
            "rating": 3.8,
            "recommendTimes": 10
        }
    },
    {
        "id": 3,
        "name": "Special Mode",
        "description": "some description here",
        "gameModeStats": {
            "id": 3,
            "region": "fi",
            "playedTimes": 100,
            "rating": 4.8,
            "recommendTimes": 10
        }
    }
]
```

### Persistence layer and Class diagram

![Entity diagram](https://github.com/duy0611/public-files/blob/master/images/epic-games-assignment2-entity-diagram.png?raw=true "Entity diagram")

* Region: Pre-defined all the regions, e.g. fi=Finland, uk=United Kingdom, us=United States etc...
* User: Represent single player in the game. User can login with his email and password
* GameMode: Represent the mode in which game is being played
* GameModeStats: In order to know which game modes are the current most popular ones, we need to keep track its statistics, like how many time it has been played, what is the rating, how many times it has been recomended etc...
* Game: Represent the single game in the platform. It has reference to User (who plays the game), Region (in which region game is being played) and GameMode (in which game mode game is being played). When new game is created, the service will also update the corresponding game mode stats in the same region player is located

### Service layer and Class diagram

```java
class GameService {
    Game findById(Long id);
    Game createOrUpdate(Game entity);
    void remove(Long id);
}

class UserService {
    User findByEmail(String email);
    String getCurrentUserRegion();
}

class GameModeService {
    GameMode findById(Long id);
    List<GameMode> findCurrentMostPopular(String countryCode);
    GameModeStats findStatsByRegion(String countryCode);
}
```

### Presentation layer and Class diagram

```java
class GameController {

    @Autowired
    GameService gameService;

    // GET /v1/api/games/:id
    ResponseEntity<Game> get(Long id) {
        return ResponseUtil.wrapOrNotFound(
            Optional.ofNullable(gameService.findById(id))
        );
    }
}

class GameModeController {

    @Autowired
    GameModeService gameModeService;

    @Autowired
    UserService userService;

    // GET /v1/api/gameModes/mostPopular?countryCode=fi
    List<GameMode> getCurrentMostPopular(@RequestParam String countryCode) {
        if (StringUtils.isNullOrWhitespace(countryCode)) {
            countryCode = userService.getCurrentUserRegion();
        }
        return gameModeService.findCurrentMostPopular(countryCode);
    }
}
```

### High level architecture design

To support for millions of users playing the game simultaneously, we will use microservice architecture as in the design below:

![Architecture diagram](https://github.com/duy0611/public-files/blob/master/images/epic-games-assignment2-architecture-diagram.png?raw=true "Architecture diagram")

* Statelessness: Communication between client and server is stateless and the API requests is authorized by authentication token (e.g. Json Web Token, extracted from browser cookies or HTTP Header)
* Caching: requests that only retrieve data are cached. We do apply caching not only on presentation layer but also on persistence layer to reduce the load on Database
* Asynchronous processing: RESTful APIs can be designed asynchronously as well as DB queries. This should help to reduce the load on CPU and Memory of the server, therefore increase the throughput 
* Message queue: In order to avoid blocking and concurrent exception when multiple users playing the same game mode at the same time, we can use message queue to deliver the event when new game is created in order to update its corresponding game mode statistics
* Monitoring: Monitoring should be applied so that during high peak time, more instances of User service and Game service will be scaled up to increase the throughput

## Question 3

### Estimated time: 30 mins

All source codes can be found from here: [epic_assignment3_source](https://github.com/duy0611/public-files/tree/master/folders/epic_assignment3) Or download the zip file here: [epic_assignment3_archive](https://github.com/duy0611/public-files/raw/master/archives/epic_assignment3.tar.xz)

I used the TDD - Test Driven Development when solving this problem. Unit Test class has been written first, and the implementation is done later until the unit test passes.

In order to verify the correstness of the solution, I used the UnitTest to verify that, with different test cases.

## Question 4

### Estimated time: 30 mins

All source codes can be found from here: [epic_assignment4_source](https://github.com/duy0611/public-files/tree/master/folders/epic_assignment4) Or download the zip file here: [epic_assignment4_archive](https://github.com/duy0611/public-files/raw/master/archives/epic_assignment4.tar.xz)

I used the TDD - Test Driven Development when solving this problem. Unit Test class has been written first, and the implementation is done later until the unit test passes.

In order to verify the correstness of the solution, I used the UnitTest to verify that, with different test cases.